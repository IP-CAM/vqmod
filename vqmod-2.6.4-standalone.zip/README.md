vqmod
=====

vQmod official repository

Please ensure you download from the RELEASES link above, or here - https://github.com/vqmod/vqmod/releases
The official source code splits out platforms and will not run correctly if you don't use a proper release zip from the above link

Installation video for OpenCart - click image to view

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/ezS1jWoMmjc/0.jpg)](http://www.youtube.com/watch?v=ezS1jWoMmjc)
